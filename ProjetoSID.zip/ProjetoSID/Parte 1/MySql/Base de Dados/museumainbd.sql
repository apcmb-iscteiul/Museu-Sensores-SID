-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 12-Abr-2020 às 19:33
-- Versão do servidor: 10.4.11-MariaDB
-- versão do PHP: 7.2.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `museumainbd`
--

DELIMITER $$
--
-- Procedimentos
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `Apagar_Utilizador` (IN `Nome` VARCHAR(200), IN `Email` VARCHAR(100))  DELETE FROM utilizador WHERE NomeUtilizador=Nome OR EmailUtilizador=Email$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Atualizar_Utilizador` (IN `email` VARCHAR(100), IN `Nome` VARCHAR(200), IN `pass` VARCHAR(12), IN `morada` VARCHAR(200), IN `tipo` VARCHAR(3))  UPDATE utilizador SET NomeUtilizador=Nome, Passwordd=pass, Morada=morada, TipoUtilizador=tipo WHERE EmailUtilizador=email$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Criar_Utilizador` (IN `Email` VARCHAR(100), IN `Nome` VARCHAR(200), IN `Password` VARCHAR(12), IN `Morada` VARCHAR(200), IN `Tipo` VARCHAR(3))  INSERT INTO utilizador (EmailUtilizador, NomeUtilizador, Passwordd, Morada, TipoUtilizador) 
VALUES(Email, Nome, Password, Morada, Tipo)$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `ExportAlertasLog` ()  select * from alertaslog where Export = 0             
into OUTFILE "C:/xampp/mysql/data/migracaologs/alertas_log.csv"
COLUMNS TERMINATED BY ';' 					
OPTIONALLY ENCLOSED BY '"'
ESCAPED BY '"' 
LINES TERMINATED BY '\r\n'$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `ExportMedicoesLog` ()  select * from medicoeslog where Export = 0             
into OUTFILE "C:/xampp/mysql/data/migracaologs/medicoes_log.csv"
COLUMNS TERMINATED BY ';' 					
OPTIONALLY ENCLOSED BY '"'
ESCAPED BY '"' 
LINES TERMINATED BY '\r\n'$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `ExportRondaExtraLog` ()  select * from rondaextralog where Export = 0       
into OUTFILE "C:/xampp/mysql/data/migracaologs/ronda_extra_log.csv"
COLUMNS TERMINATED BY ';' 					
OPTIONALLY ENCLOSED BY '"'
ESCAPED BY '"' 
LINES TERMINATED BY '\r\n'$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `ExportRondaPlaneadaLog` ()  select * from rondaplaneadalog where Export = 0   into OUTFILE "C:/xampp/mysql/data/migracaologs/ronda_planeada_log.csv"
COLUMNS TERMINATED BY ';' 					
OPTIONALLY ENCLOSED BY '"'
ESCAPED BY '"' 
LINES TERMINATED BY '\r\n'$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `ExportSistemaLog` ()  select * from sistemalog where Export = 0             
into OUTFILE "C:/xampp/mysql/data/migracaologs/sistema_log.csv"
COLUMNS TERMINATED BY ';' 					
OPTIONALLY ENCLOSED BY '"'
ESCAPED BY '"' 
LINES TERMINATED BY '\r\n'$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `ExportUtilizadorLog` ()  select * from utilizadorlog where Export = 0             
into OUTFILE "C:/xampp/mysql/data/migracaologs/utilizador_log.csv"
COLUMNS TERMINATED BY ';' 					
OPTIONALLY ENCLOSED BY '"'
ESCAPED BY '"' 
LINES TERMINATED BY '\r\n'$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `UpdateExportAlertasLog` ()  NO SQL
UPDATE alertaslog SET Export = 1$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `UpdateExportMedicoesLog` ()  MODIFIES SQL DATA
UPDATE medicoeslog SET Export = 1$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `UpdateExportRondaExtraLog` ()  MODIFIES SQL DATA
UPDATE rondaextralog SET Export = 1$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `UpdateExportRondaPlaneadaLog` ()  MODIFIES SQL DATA
UPDATE rondaplaneadalog SET Export = 1$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `UpdateExportSistemaLog` ()  MODIFIES SQL DATA
UPDATE sistemalog SET Export = 1$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `UpdateExportUtilizadorLog` ()  MODIFIES SQL DATA
UPDATE utilizadorlog SET Export = 1$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Ver_Todos_Utilizadores` ()  SELECT EmailUtilizador, NomeUtilizador, Morada, TipoUtilizador from utilizador$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Ver_Utilizador` (IN `Nome` VARCHAR(200), IN `Email` VARCHAR(100))  SELECT EmailUtilizador, NomeUtilizador, Morada, TipoUtilizador FROM utilizador WHERE NomeUtilizador=Nome OR EmailUtilizador=Email$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Estrutura da tabela `alertas`
--

CREATE TABLE `alertas` (
  `IDAlerta` int(11) NOT NULL,
  `IDmedicao` int(11) NOT NULL,
  `EstadoAlerta` int(1) NOT NULL,
  `Descricao` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `alertas`
--

INSERT INTO `alertas` (`IDAlerta`, `IDmedicao`, `EstadoAlerta`, `Descricao`) VALUES
(2, 2, 2, 'teste do delete');

--
-- Acionadores `alertas`
--
DELIMITER $$
CREATE TRIGGER `Delete_Alertas` AFTER DELETE ON `alertas` FOR EACH ROW INSERT INTO alertaslog VALUES(null, old.IDalerta, old.IDmedicao, old.EstadoAlerta, old.Descricao, "D", now(), CURRENT_USER, 0)
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `Insert_Alertas` AFTER INSERT ON `alertas` FOR EACH ROW INSERT INTO alertaslog VALUES(null, new.IDalerta, new.IDmedicao, new.EstadoAlerta, new.Descricao, "I", now(), CURRENT_USER, 0)
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `Update_Alertas` AFTER UPDATE ON `alertas` FOR EACH ROW INSERT INTO alertaslog VALUES(null, new.IDalerta, new.IDmedicao, new.EstadoAlerta, new.Descricao, "U", now(), CURRENT_USER, 0)
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Estrutura da tabela `alertaslog`
--

CREATE TABLE `alertaslog` (
  `IDlog` int(11) NOT NULL,
  `IDalerta` int(11) NOT NULL,
  `IDmedicao` int(11) NOT NULL,
  `EstadoAlerta` int(11) NOT NULL,
  `Descricao` varchar(100) DEFAULT NULL,
  `Operacao` varchar(200) NOT NULL,
  `dataOperacao` date NOT NULL,
  `userOperacao` varchar(100) NOT NULL,
  `Export` int(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `alertaslog`
--

INSERT INTO `alertaslog` (`IDlog`, `IDalerta`, `IDmedicao`, `EstadoAlerta`, `Descricao`, `Operacao`, `dataOperacao`, `userOperacao`, `Export`) VALUES
(1, 1, 2, 5, 'temp no maximo permitido ', 'I', '2020-04-12', 'root@localhost', 0),
(2, 1, 2, 2, 'alerta desnecessário ', 'U', '2020-04-12', 'root@localhost', 0),
(3, 2, 2, 2, 'teste do delete', 'I', '2020-04-12', 'root@localhost', 0),
(4, 1, 2, 2, 'alerta desnecessário ', 'D', '2020-04-12', 'root@localhost', 0);

-- --------------------------------------------------------

--
-- Estrutura da tabela `diasemana`
--

CREATE TABLE `diasemana` (
  `DiaSemana` varchar(20) NOT NULL,
  `HoraRonda` time DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `diasemana`
--

INSERT INTO `diasemana` (`DiaSemana`, `HoraRonda`) VALUES
('Segunda', '09:00:00'),
('Terça', '09:30:00');

-- --------------------------------------------------------

--
-- Estrutura da tabela `medicoeslog`
--

CREATE TABLE `medicoeslog` (
  `IDlog` int(11) NOT NULL,
  `IDmedicao` int(11) NOT NULL,
  `ValorMedicaoOld` decimal(6,2) DEFAULT NULL,
  `ValorMedicaoNew` decimal(6,2) DEFAULT NULL,
  `TipoSensor` varchar(3) NOT NULL,
  `DataHoraMedicao` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `Operacao` varchar(200) NOT NULL,
  `DataOperacao` date NOT NULL,
  `UserOperacao` varchar(100) NOT NULL,
  `Export` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `medicoeslog`
--

INSERT INTO `medicoeslog` (`IDlog`, `IDmedicao`, `ValorMedicaoOld`, `ValorMedicaoNew`, `TipoSensor`, `DataHoraMedicao`, `Operacao`, `DataOperacao`, `UserOperacao`, `Export`) VALUES
(1, 1, NULL, '100.00', 'hum', '2020-04-12 16:46:52', 'I', '2020-04-12', 'root@localhost', 0),
(2, 1, '100.00', '200.00', 'hum', '2020-04-12 16:47:11', 'U', '2020-04-12', 'root@localhost', 0),
(3, 2, NULL, '300.00', 'tmp', '2020-04-12 16:47:56', 'I', '2020-04-12', 'root@localhost', 0),
(4, 1, NULL, '200.00', 'hum', '2020-04-12 16:47:11', 'D', '2020-04-12', 'root@localhost', 0);

-- --------------------------------------------------------

--
-- Estrutura da tabela `medicoessensores`
--

CREATE TABLE `medicoessensores` (
  `IDmedicao` int(11) NOT NULL,
  `ValorMedicaoOld` decimal(6,2) DEFAULT NULL,
  `ValorMedicaoNew` decimal(6,2) DEFAULT NULL,
  `TipoSensor` varchar(3) NOT NULL,
  `DataHoraMedicao` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `medicoessensores`
--

INSERT INTO `medicoessensores` (`IDmedicao`, `ValorMedicaoOld`, `ValorMedicaoNew`, `TipoSensor`, `DataHoraMedicao`) VALUES
(2, NULL, '300.00', 'tmp', '2020-04-12 16:47:56');

--
-- Acionadores `medicoessensores`
--
DELIMITER $$
CREATE TRIGGER `Delete_MedicoesSensores` AFTER DELETE ON `medicoessensores` FOR EACH ROW INSERT INTO medicoeslog VALUES(null, old.IDmedicao, old.ValorMedicaoOld, old.ValorMedicaoNew, old.TipoSensor,old.DataHoraMedicao, "D", now(), CURRENT_USER, 0)
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `Insert_MedicoesSensores` AFTER INSERT ON `medicoessensores` FOR EACH ROW INSERT INTO medicoeslog VALUES(null, new.IDmedicao, new.ValorMedicaoOld, new.ValorMedicaoNew, new.TipoSensor,new.DataHoraMedicao, "I", now(), CURRENT_USER, 0)
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `Update_MecicoesSensores` AFTER UPDATE ON `medicoessensores` FOR EACH ROW INSERT INTO medicoeslog VALUES(null, new.IDmedicao, old.ValorMedicaoNew, new.ValorMedicaoNew, new.TipoSensor,new.DataHoraMedicao, "U", now(), CURRENT_USER, 0)
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Estrutura da tabela `rondaextra`
--

CREATE TABLE `rondaextra` (
  `IDrondaExtra` int(11) NOT NULL,
  `EmailUtilizador` varchar(100) NOT NULL,
  `dataHora` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `rondaextra`
--

INSERT INTO `rondaextra` (`IDrondaExtra`, `EmailUtilizador`, `dataHora`) VALUES
(2, 'bbbb', '2020-04-12 17:00:51');

--
-- Acionadores `rondaextra`
--
DELIMITER $$
CREATE TRIGGER `Delete_RondaExtra` AFTER DELETE ON `rondaextra` FOR EACH ROW INSERT INTO rondaextralog VALUES(null, old.EmailUtilizador, old.dataHora, "D", now(), CURRENT_USER, 0)
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `Insert_RondaExtra` AFTER INSERT ON `rondaextra` FOR EACH ROW INSERT INTO rondaextralog VALUES(null, new.EmailUtilizador, new.dataHora, "I", now(), CURRENT_USER, 0)
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `Update_RondaExtra` AFTER UPDATE ON `rondaextra` FOR EACH ROW INSERT INTO rondaextralog VALUES(null, new.EmailUtilizador, new.dataHora, "U", now(), CURRENT_USER, 0)
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Estrutura da tabela `rondaextralog`
--

CREATE TABLE `rondaextralog` (
  `IDlog` int(11) NOT NULL,
  `EmailUtilizador` varchar(100) NOT NULL,
  `dataHora` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `Operacao` varchar(200) NOT NULL,
  `dataOperacao` date NOT NULL,
  `UserOperacao` varchar(100) NOT NULL,
  `Export` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `rondaextralog`
--

INSERT INTO `rondaextralog` (`IDlog`, `EmailUtilizador`, `dataHora`, `Operacao`, `dataOperacao`, `UserOperacao`, `Export`) VALUES
(2, 'bbbb', '2020-04-12 16:59:49', 'I', '2020-04-12', 'root@localhost', 0),
(3, 'bbbb', '2020-04-15 16:59:49', 'U', '2020-04-12', 'root@localhost', 0),
(4, 'bbbb', '2020-04-12 17:00:51', 'I', '2020-04-12', 'root@localhost', 0),
(5, 'bbbb', '2020-04-15 16:59:49', 'D', '2020-04-12', 'root@localhost', 0);

-- --------------------------------------------------------

--
-- Estrutura da tabela `rondaplaneada`
--

CREATE TABLE `rondaplaneada` (
  `IDRondaPlaneada` int(11) NOT NULL,
  `DiaSemana` varchar(20) NOT NULL,
  `EmailUtilizador` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `rondaplaneada`
--

INSERT INTO `rondaplaneada` (`IDRondaPlaneada`, `DiaSemana`, `EmailUtilizador`) VALUES
(2, 'Terça', 'bbbb');

--
-- Acionadores `rondaplaneada`
--
DELIMITER $$
CREATE TRIGGER `Delete_RondaPlaneada` AFTER DELETE ON `rondaplaneada` FOR EACH ROW INSERT INTO rondaplaneadalog VALUES(null, old.DiaSemana, old.EmailUtilizador, "D", now(), CURRENT_USER,0)
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `Insert_RondaPlaneada` AFTER INSERT ON `rondaplaneada` FOR EACH ROW INSERT INTO rondaplaneadalog VALUES(null, new.DiaSemana, new.EmailUtilizador, "I", now(), CURRENT_USER,0)
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `Update_RondaPlaneada` AFTER UPDATE ON `rondaplaneada` FOR EACH ROW INSERT INTO rondaplaneadalog values(null, new.DiaSemana, new.EmailUtilizador, "U", now(), CURRENT_USER, 0)
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Estrutura da tabela `rondaplaneadalog`
--

CREATE TABLE `rondaplaneadalog` (
  `IDlog` int(11) NOT NULL,
  `DiaSemana` varchar(20) NOT NULL,
  `EmailUtilizador` varchar(100) NOT NULL,
  `Operacao` varchar(200) NOT NULL,
  `dataOperacao` date NOT NULL,
  `UserOperacao` varchar(100) NOT NULL,
  `Export` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `rondaplaneadalog`
--

INSERT INTO `rondaplaneadalog` (`IDlog`, `DiaSemana`, `EmailUtilizador`, `Operacao`, `dataOperacao`, `UserOperacao`, `Export`) VALUES
(2, 'Segunda', 'bbbb', 'I', '2020-04-12', 'root@localhost', 0),
(3, 'Terça', 'bbbb', 'U', '2020-04-12', 'root@localhost', 0),
(4, 'Terça', 'bbbb', 'I', '2020-04-12', 'root@localhost', 0),
(5, 'Terça', 'bbbb', 'D', '2020-04-12', 'root@localhost', 0);

-- --------------------------------------------------------

--
-- Estrutura da tabela `sistema`
--

CREATE TABLE `sistema` (
  `IDsistema` int(11) NOT NULL,
  `LimiteTemperatura` decimal(6,2) DEFAULT NULL,
  `LimiteHumidade` decimal(6,2) DEFAULT NULL,
  `LimiteLuminosidade` decimal(6,2) DEFAULT NULL,
  `EstadoMovimento` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `sistema`
--

INSERT INTO `sistema` (`IDsistema`, `LimiteTemperatura`, `LimiteHumidade`, `LimiteLuminosidade`, `EstadoMovimento`) VALUES
(2, '2.00', '3.00', '4.00', 1);

--
-- Acionadores `sistema`
--
DELIMITER $$
CREATE TRIGGER `Delete_Sistema` AFTER DELETE ON `sistema` FOR EACH ROW INSERT INTO sistemalog VALUES(null, old.LimiteTemperatura, old.LimiteHumidade, old.LimiteLuminosidade, old.EstadoMovimento, "D", now(), CURRENT_USER, 0)
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `Insert_Sistema` AFTER INSERT ON `sistema` FOR EACH ROW INSERT INTO sistemalog VALUES(null, new.LimiteTemperatura, new.LimiteHumidade, new.LimiteLuminosidade, new.EstadoMovimento, "I", now(), CURRENT_USER, 0)
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `Update_Sistema` AFTER UPDATE ON `sistema` FOR EACH ROW INSERT INTO sistemalog VALUES(null, new.LimiteTemperatura, new.LimiteHumidade, new.LimiteLuminosidade, new.EstadoMovimento, "U", now(), CURRENT_USER, 0)
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Estrutura da tabela `sistemalog`
--

CREATE TABLE `sistemalog` (
  `IDlog` int(11) NOT NULL,
  `LimiteTemperatura` decimal(6,2) NOT NULL,
  `LimiteHumidade` decimal(6,2) NOT NULL,
  `LimiteLuminosidade` decimal(6,2) NOT NULL,
  `movimento` int(1) NOT NULL,
  `Operacao` varchar(200) NOT NULL,
  `dataOperacao` date NOT NULL,
  `UserOperacao` varchar(100) NOT NULL,
  `Export` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `sistemalog`
--

INSERT INTO `sistemalog` (`IDlog`, `LimiteTemperatura`, `LimiteHumidade`, `LimiteLuminosidade`, `movimento`, `Operacao`, `dataOperacao`, `UserOperacao`, `Export`) VALUES
(35, '5555.00', '6.11', '3.99', 0, 'I', '2020-04-12', 'root@localhost', 0),
(36, '5555.00', '6.11', '3.99', 0, 'U', '2020-04-12', 'root@localhost', 0),
(37, '2.00', '3.00', '4.00', 1, 'I', '2020-04-12', 'root@localhost', 0),
(38, '5555.00', '6.11', '3.99', 0, 'D', '2020-04-12', 'root@localhost', 0);

-- --------------------------------------------------------

--
-- Estrutura da tabela `utilizador`
--

CREATE TABLE `utilizador` (
  `EmailUtilizador` varchar(100) NOT NULL,
  `NomeUtilizador` varchar(200) NOT NULL,
  `Passwordd` varchar(12) NOT NULL,
  `Morada` varchar(200) NOT NULL DEFAULT 'NOT NULL',
  `TipoUtilizador` varchar(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `utilizador`
--

INSERT INTO `utilizador` (`EmailUtilizador`, `NomeUtilizador`, `Passwordd`, `Morada`, `TipoUtilizador`) VALUES
('bbbb', 'joao', 'lalala', 'almirante reis', 'seg');

--
-- Acionadores `utilizador`
--
DELIMITER $$
CREATE TRIGGER `Delete_Utilizador` AFTER DELETE ON `utilizador` FOR EACH ROW INSERT INTO utilizadorlog VALUES(null, old.EmailUtilizador, old.NomeUtilizador, old.Morada, old.Passwordd, old.TipoUtilizador, "D", now(), CURRENT_USER,0)
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `Insert_Utilizador` AFTER INSERT ON `utilizador` FOR EACH ROW INSERT INTO utilizadorlog VALUES(null, new.EmailUtilizador, new.NomeUtilizador, new.Passwordd, new.Morada, new.TipoUtilizador, "I", now(), CURRENT_USER, 0)
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `Update_Utilizador` AFTER UPDATE ON `utilizador` FOR EACH ROW INSERT INTO utilizadorlog VALUES(null, new.EmailUtilizador, new.NomeUtilizador, new.Passwordd, new.Morada, new.TipoUtilizador, "U", now(), CURRENT_USER,0)
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Estrutura da tabela `utilizadorlog`
--

CREATE TABLE `utilizadorlog` (
  `IDlog` int(11) NOT NULL,
  `EmailUtilizador` varchar(100) NOT NULL,
  `NomeUtilizador` varchar(200) NOT NULL,
  `Passwordd` varchar(12) NOT NULL,
  `Morada` varchar(200) NOT NULL,
  `TipoUtilizador` varchar(3) NOT NULL,
  `Operacao` varchar(200) NOT NULL,
  `DataOperacao` date NOT NULL,
  `UserOperacao` varchar(100) NOT NULL,
  `Export` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `utilizadorlog`
--

INSERT INTO `utilizadorlog` (`IDlog`, `EmailUtilizador`, `NomeUtilizador`, `Passwordd`, `Morada`, `TipoUtilizador`, `Operacao`, `DataOperacao`, `UserOperacao`, `Export`) VALUES
(213241, 'aaaa', 'Luis', '*A00D6EEF76E', 'rua joaquim bastos', 'dir', 'I', '2020-04-12', 'root@localhost', 0),
(213242, 'aaaa', 'Luis', 'teste', 'rua joaquim bastos', 'dir', 'U', '2020-04-12', 'root@localhost', 0),
(213243, 'bbbb', 'joao', 'lalala', 'almirante reis', 'seg', 'I', '2020-04-12', 'root@localhost', 0),
(213244, 'aaaa', 'Luis', 'rua joaquim ', 'teste', 'dir', 'D', '2020-04-12', 'root@localhost', 0);

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `alertas`
--
ALTER TABLE `alertas`
  ADD PRIMARY KEY (`IDAlerta`),
  ADD KEY `IDMedicao_fk` (`IDmedicao`);

--
-- Índices para tabela `alertaslog`
--
ALTER TABLE `alertaslog`
  ADD PRIMARY KEY (`IDlog`);

--
-- Índices para tabela `diasemana`
--
ALTER TABLE `diasemana`
  ADD PRIMARY KEY (`DiaSemana`);

--
-- Índices para tabela `medicoeslog`
--
ALTER TABLE `medicoeslog`
  ADD PRIMARY KEY (`IDlog`);

--
-- Índices para tabela `medicoessensores`
--
ALTER TABLE `medicoessensores`
  ADD PRIMARY KEY (`IDmedicao`);

--
-- Índices para tabela `rondaextra`
--
ALTER TABLE `rondaextra`
  ADD PRIMARY KEY (`IDrondaExtra`),
  ADD KEY `EmailUtilizador_fk` (`EmailUtilizador`);

--
-- Índices para tabela `rondaextralog`
--
ALTER TABLE `rondaextralog`
  ADD PRIMARY KEY (`IDlog`);

--
-- Índices para tabela `rondaplaneada`
--
ALTER TABLE `rondaplaneada`
  ADD PRIMARY KEY (`IDRondaPlaneada`),
  ADD KEY `EmailUtilizador_fk2` (`EmailUtilizador`),
  ADD KEY `DiaSemana_fk` (`DiaSemana`);

--
-- Índices para tabela `rondaplaneadalog`
--
ALTER TABLE `rondaplaneadalog`
  ADD PRIMARY KEY (`IDlog`);

--
-- Índices para tabela `sistema`
--
ALTER TABLE `sistema`
  ADD PRIMARY KEY (`IDsistema`);

--
-- Índices para tabela `sistemalog`
--
ALTER TABLE `sistemalog`
  ADD PRIMARY KEY (`IDlog`);

--
-- Índices para tabela `utilizador`
--
ALTER TABLE `utilizador`
  ADD PRIMARY KEY (`EmailUtilizador`);

--
-- Índices para tabela `utilizadorlog`
--
ALTER TABLE `utilizadorlog`
  ADD PRIMARY KEY (`IDlog`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `alertas`
--
ALTER TABLE `alertas`
  MODIFY `IDAlerta` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de tabela `alertaslog`
--
ALTER TABLE `alertaslog`
  MODIFY `IDlog` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de tabela `medicoeslog`
--
ALTER TABLE `medicoeslog`
  MODIFY `IDlog` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de tabela `medicoessensores`
--
ALTER TABLE `medicoessensores`
  MODIFY `IDmedicao` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de tabela `rondaextra`
--
ALTER TABLE `rondaextra`
  MODIFY `IDrondaExtra` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de tabela `rondaextralog`
--
ALTER TABLE `rondaextralog`
  MODIFY `IDlog` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de tabela `rondaplaneada`
--
ALTER TABLE `rondaplaneada`
  MODIFY `IDRondaPlaneada` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de tabela `rondaplaneadalog`
--
ALTER TABLE `rondaplaneadalog`
  MODIFY `IDlog` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de tabela `sistemalog`
--
ALTER TABLE `sistemalog`
  MODIFY `IDlog` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT de tabela `utilizadorlog`
--
ALTER TABLE `utilizadorlog`
  MODIFY `IDlog` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=213245;

--
-- Restrições para despejos de tabelas
--

--
-- Limitadores para a tabela `alertas`
--
ALTER TABLE `alertas`
  ADD CONSTRAINT `IDMedicao_fk` FOREIGN KEY (`IDmedicao`) REFERENCES `medicoessensores` (`IDmedicao`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Limitadores para a tabela `rondaextra`
--
ALTER TABLE `rondaextra`
  ADD CONSTRAINT `EmailUtilizador_fk` FOREIGN KEY (`EmailUtilizador`) REFERENCES `utilizador` (`EmailUtilizador`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Limitadores para a tabela `rondaplaneada`
--
ALTER TABLE `rondaplaneada`
  ADD CONSTRAINT `DiaSemana_fk` FOREIGN KEY (`DiaSemana`) REFERENCES `diasemana` (`DiaSemana`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `EmailUtilizador_fk2` FOREIGN KEY (`EmailUtilizador`) REFERENCES `utilizador` (`EmailUtilizador`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
