package sensor;

import org.bson.Document;

public class Medicao {
	private String temperatura;
	private String humidade;
	private String luz;
	private Float mov;
	private String data;
	private String hora;
	private Integer migrado;
	private String tipoSensor;
	private Document documento;
	private Float tmpNum;
	private Float humNum;
	private Float luzNum;
	
	public Medicao(Object temperatura, Object humidade, Object luz, Object mov, Object data, Object hora, Integer migrado, Document documento ) {
		this.temperatura= temperatura.toString();
		this.humidade= humidade.toString();
		this.luz= luz.toString();
		this.mov= Float.valueOf(mov.toString());
		this.data= data.toString();
		this.hora= hora.toString();
		this.migrado= migrado;
		this.documento=documento;
		this.tmpNum = Float.valueOf(temperatura.toString());
		this.humNum = Float.valueOf(humidade.toString());
		this.luzNum = Float.valueOf(luz.toString());
	}
					
	public String getTemperatura() {
		return temperatura;
	}

	public void setTemperatura(String temperatura) {
		this.temperatura = temperatura;
	}

	public String getHumidade() {
		return humidade;
	}

	public void setHumidade(String humidade) {
		this.humidade = humidade;
	}

	public String getLuz() {
		return luz;
	}

	public void setLuz(String luz) {
		this.luz = luz;
	}
	
	public Float getMov() {
		return mov;
	}

	public String getData() {
		return data;
	}

	public void setData(String data) {
		this.data = data;
	}

	public String getHora() {
		return hora;
	}

	public void setHora(String hora) {
		this.hora = hora;
	}

	public Integer getMigrado() {
		return migrado;
	}

	public void setMigrado(Integer migrado) {
		this.migrado = migrado;
	}

	public String getTipoSensor() {
		return tipoSensor;
	}

	public void setTipoSensor(String tipoSensor) {
		this.tipoSensor = tipoSensor;
	}

	public Document getDocumento() {
		return documento;
	}

	public void setDocumento(Document documento) {
		this.documento = documento;
	}

	public Float getTmpNum() {
		return tmpNum;
	}

	public Float getHumNum() {
		return humNum;
	}

	public Float getLuzNum() {
		return luzNum;
	}

	public void setCell(float cell) {
		this.luzNum = cell;
	}
	
	public String callSpTmp() {
		return "CALL SP_TMP("+tmpNum+",'tmp','"+data+" "+hora+"');";
	}
	
	public String callSpHum() {
		return "CALL SP_HUM("+humNum+",'hum','"+data+" "+hora+"');";
	}
	
	public String callSpLuz() {
		return "CALL SP_LUZ("+luzNum+",'luz','"+data+" "+hora+"');";
	}
	
	public String callSpMov() {
		return "CALL SP_MOV("+mov+",'mov','"+data+" "+hora+"');";
	}
}
