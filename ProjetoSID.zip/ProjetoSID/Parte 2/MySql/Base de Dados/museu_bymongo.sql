-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 31, 2020 at 07:11 AM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.2.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `museu_bymongo`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_HUM` (IN `in_medicao` FLOAT(6,2), IN `in_tipo` VARCHAR(3), IN `in_dataHora` TIMESTAMP)  NO SQL
BEGIN
	
    DECLARE v_limite FLOAT;
    DECLARE v_preLimite FLOAT(6,2);
    DECLARE v_intervalo TIME;    
    DECLARE v_descricao VARCHAR(1000);
    DECLARE v_tempo timestamp;
    DECLARE v_posso BOOLEAN;
    DECLARE v_alerta INT;
    DECLARE v_preAlerta INT;
      
    -- Obtem valores dos limites da tabela sistema  
    SELECT LimiteHumidade, PreLimiteHumidade, IntervaloAlertas
      INTO v_limite, v_preLimite, v_intervalo
      FROM Sistema
	  LIMIT 1;
       
     -- Insere a medicao na tabela das medicoes  
      INSERT INTO medicoessensores (ValorMedicao, TipoSensor, DataHoraMedicao) 
      VALUES (in_medicao, in_tipo, in_dataHora);
     
     -- Se a medicao passar o limite, conta se ja ha algum alerta do mesmo tipo
      IF in_medicao >= v_limite THEN
      	SELECT COUNT(1)
        INTO v_alerta
        FROM Alerta
        WHERE TipoSensor=in_tipo AND Descricao="Humidade excedeu o limite!";
      
      -- Obtem dadaHora de medicao e verifica se o tempo  da medicao mais o intervalo de alertas é menor que o tempo atual, ou seja, se ja passou o tempo do intervalo depois da medicao ser feita. COnta o ultimo igual
          SELECT DataHoraMedicao, Descricao, ADDTIME(DataHoraMedicao, v_intervalo) <= CURRENT_TIMESTAMP
          INTO v_tempo, v_descricao, v_posso
          FROM alerta
          WHERE TipoSensor=in_tipo AND Descricao="Humidade excedeu o limite!"
          ORDER BY ID DESC
          LIMIT 1;
      
      -- Se ainda nao ha nenhum alerta, ou se ha mas ja passou o tempo do intervalo entao insere o alerta
          IF v_alerta=0 OR (v_alerta>=1 AND v_posso=TRUE) THEN
              INSERT INTO alerta (TipoSensor, ValorMedicao, Limite, Descricao, DataHoraMedicao)
              VALUES (in_tipo, in_medicao, v_limite, "Humidade excedeu o limite!", in_dataHora);
      
      	  END IF;
      
      -- Se a medicao esta acima do pre limite e abaixo do limite, e se ja houver algum pre alerta conta 1
      ELSEIF in_medicao>=v_preLimite AND in_medicao<v_limite THEN
      	SELECT COUNT(1)
        INTO v_preAlerta
        FROM Alerta
        WHERE TipoSensor=in_tipo AND Descricao="Humidade está próxima do limite!";
        
        -- - Obtem dadaHora de medicao e verifica se o tempo  da medicao mais o intervalo de alertas é menor que o tempo atual, ou seja, se ja passou o tempo do intervalo depois da medicao ser feita. Conta o ultimo com essa descricao
          SELECT DataHoraMedicao, Descricao, ADDTIME(DataHoraMedicao, v_intervalo) <= CURRENT_TIMESTAMP
          INTO v_tempo, v_descricao, v_posso
          FROM alerta
          WHERE TipoSensor=in_tipo AND Descricao="Humidade está próxima do limite!"
          ORDER BY ID DESC
          LIMIT 1;
      
      -- Se nao ha nenhum pre alerta ou se ja ha mas ja passou o tempo do intervalo, entao insere nos alertas
          IF v_preAlerta=0 OR (v_preAlerta>=1 AND v_posso=TRUE) THEN
              INSERT INTO alerta (TipoSensor, ValorMedicao, Limite, Descricao, DataHoraMedicao)
              VALUES (in_tipo, in_medicao, v_preLimite, "Humidade está próxima do limite!", in_dataHora);
      
      	  END IF;
          
	  END IF;      
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_LUZ` (IN `in_medicao` FLOAT(6,2), IN `in_tipo` VARCHAR(3), IN `in_dataHora` TIMESTAMP)  NO SQL
BEGIN
	
    DECLARE v_limite FLOAT;
    DECLARE v_preLimite FLOAT(6,2);
    DECLARE v_intervalo TIME;    
    DECLARE v_descricao VARCHAR(1000);
    DECLARE v_tempo timestamp;
    DECLARE v_posso BOOLEAN;
    DECLARE v_alerta INT;
    DECLARE v_preAlerta INT;
      
    -- Obtem valores dos limites da tabela sistema  
    SELECT LimiteLuminosidade, PreLimiteLuminosidade, IntervaloAlertas
      INTO v_limite, v_preLimite, v_intervalo
      FROM Sistema
	  LIMIT 1;
       
     -- Insere a medicao na tabela das medicoes  
      INSERT INTO medicoessensores (ValorMedicao, TipoSensor, DataHoraMedicao) 
      VALUES (in_medicao, in_tipo, in_dataHora);
     
     -- Se a medicao passar o limite, conta se ja ha algum alerta do mesmo tipo
      IF in_medicao >= v_limite THEN
      	SELECT COUNT(1)
        INTO v_alerta
        FROM Alerta
        WHERE TipoSensor=in_tipo AND Descricao="Luminosidade excedeu o limite!";
      
      -- Obtem dadaHora de medicao e verifica se o tempo  da medicao mais o intervalo de alertas é menor que o tempo atual, ou seja, se ja passou o tempo do intervalo depois da medicao ser feita. COnta o ultimo igual
          SELECT DataHoraMedicao, Descricao, ADDTIME(DataHoraMedicao, v_intervalo) <= CURRENT_TIMESTAMP
          INTO v_tempo, v_descricao, v_posso
          FROM alerta
          WHERE TipoSensor=in_tipo AND Descricao="Luminosidade excedeu o limite!"
          ORDER BY ID DESC
          LIMIT 1;
      
      -- Se ainda nao ha nenhum alerta, ou se ha mas ja passou o tempo do intervalo entao insere o alerta
          IF v_alerta=0 OR (v_alerta>=1 AND v_posso=TRUE) THEN
              INSERT INTO alerta (TipoSensor, ValorMedicao, Limite, Descricao, DataHoraMedicao)
              VALUES (in_tipo, in_medicao, v_limite, "Luminosidade excedeu o limite!", in_dataHora);
      
      	  END IF;
      
      -- Se a medicao esta acima do pre limite e abaixo do limite, e se ja houver algum pre alerta conta 1
      ELSEIF in_medicao>=v_preLimite AND in_medicao<v_limite THEN
      	SELECT COUNT(1)
        INTO v_preAlerta
        FROM Alerta
        WHERE TipoSensor=in_tipo AND Descricao="Luminosidade está próxima do limite!";
        
        -- - Obtem dadaHora de medicao e verifica se o tempo  da medicao mais o intervalo de alertas é menor que o tempo atual, ou seja, se ja passou o tempo do intervalo depois da medicao ser feita. Conta o ultimo com essa descricao
          SELECT DataHoraMedicao, Descricao, ADDTIME(DataHoraMedicao, v_intervalo) <= CURRENT_TIMESTAMP
          INTO v_tempo, v_descricao, v_posso
          FROM alerta
          WHERE TipoSensor=in_tipo AND Descricao="Luminosidade está próxima do limite!"
          ORDER BY ID DESC
          LIMIT 1;
      
      -- Se nao ha nenhum pre alerta ou se ja ha mas ja passou o tempo do intervalo, entao insere nos alertas
          IF v_preAlerta=0 OR (v_preAlerta>=1 AND v_posso=TRUE) THEN
              INSERT INTO alerta (TipoSensor, ValorMedicao, Limite, Descricao, DataHoraMedicao)
              VALUES (in_tipo, in_medicao, v_preLimite, "Luminosidade está próxima do limite!", in_dataHora);
      
      	  END IF;
          
	  END IF;      
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_MOV` (IN `in_medicao` FLOAT, IN `in_tipo` VARCHAR(3), IN `in_dataHora` TIMESTAMP)  NO SQL
BEGIN
	
    DECLARE v_limite FLOAT;
    DECLARE v_intervalo TIME;    
    DECLARE v_descricao VARCHAR(1000);
    DECLARE v_tempo timestamp;
    DECLARE v_posso BOOLEAN;
    DECLARE v_seHaRonda BOOLEAN;
    DECLARE v_alerta INT;
    DECLARE v_intervaloRonda TIME;
    DECLARE v_inicioRonda DATETIME;
      
    -- Obtem valores dos limites da tabela sistema  
    SELECT LimiteMovimento, IntervaloRondaExtra, IntervaloAlertas
      INTO v_limite, v_intervaloRonda, v_intervalo
      FROM Sistema
	  LIMIT 1;
      
      -- Obtem dataHora da ultima ronda extra
      SELECT DataHoraRondaExtra
      INTO v_inicioRonda
      FROM rondaextra
      ORDER BY IDRondaExtra DESC
      LIMIT 1;
       
     -- Insere a medicao na tabela das medicoes  
      INSERT INTO medicoessensores (ValorMedicao, TipoSensor, DataHoraMedicao) 
      VALUES (in_medicao, in_tipo, in_dataHora);
     
     -- Se a medicao passar o limite, conta se ja ha algum alerta do mesmo tipo
      IF in_medicao >= v_limite AND SUBTIME(CURRENT_TIMESTAMP, v_intervaloRonda) >= v_inicioRonda THEN
      	SELECT COUNT(1)
        INTO v_alerta
        FROM Alerta
        WHERE TipoSensor=in_tipo AND Descricao="Movimento detetado!";
      
      -- Obtem dadaHora de medicao e verifica se o tempo  da medicao mais o intervalo de alertas é menor que o tempo atual, ou seja, se ja passou o tempo do intervalo depois da medicao ser feita. COnta o ultimo igual
          SELECT DataHoraMedicao, Descricao, ADDTIME(DataHoraMedicao, v_intervalo) <= CURRENT_TIMESTAMP
          INTO v_tempo, v_descricao, v_posso
          FROM alerta
          WHERE TipoSensor=in_tipo AND Descricao="Movimento detetado!"
          ORDER BY ID DESC
          LIMIT 1;
      
      -- Se ainda nao ha nenhum alerta, ou se ha mas ja passou o tempo do intervalo entao insere o alerta
          IF v_alerta=0 OR (v_alerta>=1 AND v_posso=TRUE) THEN
              INSERT INTO alerta (TipoSensor, ValorMedicao, Limite, Descricao, DataHoraMedicao)
              VALUES (in_tipo, in_medicao, v_limite, "Movimento detetado!", in_dataHora);
      
      	  END IF;          
	  END IF;      
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_TMP` (IN `in_medicao` FLOAT(6,2), IN `in_tipo` VARCHAR(3), IN `in_dataHora` TIMESTAMP)  NO SQL
BEGIN
	
    DECLARE v_limite FLOAT;
    DECLARE v_preLimite FLOAT(6,2);
    DECLARE v_intervalo TIME;    
    DECLARE v_descricao VARCHAR(1000);
    DECLARE v_tempo timestamp;
    DECLARE v_posso BOOLEAN;
    DECLARE v_alerta INT;
    DECLARE v_preAlerta INT;
      
    -- Obtem valores dos limites da tabela sistema  
    SELECT LimiteTemperatura, PreLimiteTemperatura, IntervaloAlertas
      INTO v_limite, v_preLimite, v_intervalo
      FROM Sistema
	  LIMIT 1;
       
     -- Insere a medicao na tabela das medicoes  
      INSERT INTO medicoessensores (ValorMedicao, TipoSensor, DataHoraMedicao) 
      VALUES (in_medicao, in_tipo, in_dataHora);
     
     -- Se a medicao passar o limite, conta se ja ha algum alerta do mesmo tipo
      IF in_medicao >= v_limite THEN
      	SELECT COUNT(1)
        INTO v_alerta
        FROM Alerta
        WHERE TipoSensor=in_tipo AND Descricao="Temperatura excedeu o limite!";
      
      -- Obtem dadaHora de medicao e verifica se o tempo  da medicao mais o intervalo de alertas é menor que o tempo atual, ou seja, se ja passou o tempo do intervalo depois da medicao ser feita. COnta o ultimo igual
          SELECT DataHoraMedicao, Descricao, ADDTIME(DataHoraMedicao, v_intervalo) <= CURRENT_TIMESTAMP
          INTO v_tempo, v_descricao, v_posso
          FROM alerta
          WHERE TipoSensor=in_tipo AND Descricao="Temperatura excedeu o limite!"
          ORDER BY ID DESC
          LIMIT 1;
      
      -- Se ainda nao ha nenhum alerta, ou se ha mas ja passou o tempo do intervalo entao insere o alerta
          IF v_alerta=0 OR (v_alerta>=1 AND v_posso=TRUE) THEN
              INSERT INTO alerta (TipoSensor, ValorMedicao, Limite, Descricao, DataHoraMedicao)
              VALUES (in_tipo, in_medicao, v_limite, "Temperatura excedeu o limite!", in_dataHora);
      
      	  END IF;
      
      -- Se a medicao esta acima do pre limite e abaixo do limite, e se ja houver algum pre alerta conta 1
      ELSEIF in_medicao>=v_preLimite AND in_medicao<v_limite THEN
      	SELECT COUNT(1)
        INTO v_preAlerta
        FROM Alerta
        WHERE TipoSensor=in_tipo AND Descricao="Temperatura está próxima do limite!";
        
        -- - Obtem dadaHora de medicao e verifica se o tempo  da medicao mais o intervalo de alertas é menor que o tempo atual, ou seja, se ja passou o tempo do intervalo depois da medicao ser feita. Conta o ultimo com essa descricao
          SELECT DataHoraMedicao, Descricao, ADDTIME(DataHoraMedicao, v_intervalo) <= CURRENT_TIMESTAMP
          INTO v_tempo, v_descricao, v_posso
          FROM alerta
          WHERE TipoSensor=in_tipo AND Descricao="Temperatura está próxima do limite!"
          ORDER BY ID DESC
          LIMIT 1;
      
      -- Se nao ha nenhum pre alerta ou se ja ha mas ja passou o tempo do intervalo, entao insere nos alertas
          IF v_preAlerta=0 OR (v_preAlerta>=1 AND v_posso=TRUE) THEN
              INSERT INTO alerta (TipoSensor, ValorMedicao, Limite, Descricao, DataHoraMedicao)
              VALUES (in_tipo, in_medicao, v_preLimite, "Temperatura está próxima do limite!", in_dataHora);
      
      	  END IF;
          
	  END IF;      
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `alerta`
--

CREATE TABLE `alerta` (
  `ID` int(11) NOT NULL,
  `DataHoraMedicao` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `TipoSensor` varchar(3) NOT NULL,
  `ValorMedicao` float(6,2) NOT NULL,
  `Limite` float(6,2) NOT NULL,
  `Descricao` varchar(1000) NOT NULL,
  `Controlo` tinyint(1) NOT NULL,
  `Extra` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `alerta`
--

INSERT INTO `alerta` (`ID`, `DataHoraMedicao`, `TipoSensor`, `ValorMedicao`, `Limite`, `Descricao`, `Controlo`, `Extra`) VALUES
(74, '2020-05-31 00:33:48', 'tmp', 35.00, 35.00, 'Temperatura está próxima do limite!', 0, ''),
(79, '2020-05-31 01:00:10', 'tmp', 40.00, 40.00, 'Temperatura excedeu o limite!', 0, ''),
(80, '2020-05-31 01:50:44', 'hum', 95.00, 95.00, 'Humidade está próxima do limite!', 0, ''),
(83, '2020-05-31 02:37:42', 'hum', 100.00, 100.00, 'Humidade excedeu o limite!', 0, ''),
(84, '2020-05-31 02:48:33', 'luz', 450.00, 450.00, 'Luminosidade está próxima do limite!', 0, ''),
(85, '2020-05-31 02:57:55', 'luz', 500.00, 500.00, 'Luminosidade excedeu o limite!', 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `medicoessensores`
--

CREATE TABLE `medicoessensores` (
  `IDmedicao` int(11) NOT NULL,
  `ValorMedicao` float(6,2) NOT NULL,
  `TipoSensor` varchar(3) NOT NULL,
  `DataHoraMedicao` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `medicoessensores`
--

INSERT INTO `medicoessensores` (`IDmedicao`, `ValorMedicao`, `TipoSensor`, `DataHoraMedicao`) VALUES
(1, 25.00, 'tmp', '2020-05-31 04:09:54'),
(2, 60.00, 'hum', '2020-05-31 04:09:54'),
(3, 300.00, 'luz', '2020-05-31 04:09:54'),
(4, 0.00, 'mov', '2020-05-31 04:09:54'),
(5, 25.00, 'tmp', '2020-05-31 04:09:55'),
(6, 60.00, 'hum', '2020-05-31 04:09:55'),
(7, 300.00, 'luz', '2020-05-31 04:09:55'),
(8, 0.00, 'mov', '2020-05-31 04:09:55'),
(9, 25.00, 'tmp', '2020-05-31 04:09:56'),
(10, 60.00, 'hum', '2020-05-31 04:09:56'),
(11, 300.00, 'luz', '2020-05-31 04:09:56'),
(12, 0.00, 'mov', '2020-05-31 04:09:56'),
(13, 25.00, 'tmp', '2020-05-31 04:13:29'),
(14, 60.00, 'hum', '2020-05-31 04:13:29'),
(15, 300.00, 'luz', '2020-05-31 04:13:29'),
(16, 1.00, 'mov', '2020-05-31 04:13:29'),
(17, 25.00, 'tmp', '2020-05-31 04:13:31'),
(18, 60.00, 'hum', '2020-05-31 04:13:31'),
(19, 300.00, 'luz', '2020-05-31 04:13:31'),
(20, 1.00, 'mov', '2020-05-31 04:13:31'),
(21, 25.00, 'tmp', '2020-05-31 04:13:33'),
(22, 60.00, 'hum', '2020-05-31 04:13:33'),
(23, 300.00, 'luz', '2020-05-31 04:13:33'),
(24, 1.00, 'mov', '2020-05-31 04:13:33'),
(25, 1.00, 'xxx', '2020-05-31 04:30:38'),
(26, 1.00, 'xxx', '2020-05-31 04:32:14'),
(27, 1.00, 'xxx', '2020-05-31 04:40:56'),
(28, 1.00, 'xxx', '2020-05-31 04:42:18'),
(29, 1.00, 'xxx', '2020-05-31 05:05:52'),
(30, 1.00, 'xxx', '2020-05-31 05:10:32');

-- --------------------------------------------------------

--
-- Table structure for table `rondaextra`
--

CREATE TABLE `rondaextra` (
  `IDrondaExtra` int(11) NOT NULL,
  `DataHoraRondaExtra` datetime NOT NULL DEFAULT current_timestamp(),
  `EmailUtilizador` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `rondaplaneada`
--

CREATE TABLE `rondaplaneada` (
  `IDrondaPlaneada` int(11) NOT NULL,
  `DiaSemana` varchar(20) NOT NULL,
  `EmailUtilizador` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `sistema`
--

CREATE TABLE `sistema` (
  `LimiteTemperatura` float(6,2) NOT NULL,
  `PreLimiteTemperatura` float(6,2) NOT NULL,
  `LimiteHumidade` float(6,2) NOT NULL,
  `PreLimiteHumidade` float(6,2) NOT NULL,
  `LimiteLuminosidade` float(6,2) NOT NULL,
  `PreLimiteLuminosidade` float(6,2) NOT NULL,
  `LimiteMovimento` int(1) NOT NULL DEFAULT 1,
  `IntervaloAlertas` time NOT NULL,
  `IntervaloRondaExtra` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `sistema`
--

INSERT INTO `sistema` (`LimiteTemperatura`, `PreLimiteTemperatura`, `LimiteHumidade`, `PreLimiteHumidade`, `LimiteLuminosidade`, `PreLimiteLuminosidade`, `LimiteMovimento`, `IntervaloAlertas`, `IntervaloRondaExtra`) VALUES
(40.00, 35.00, 100.00, 95.00, 500.00, 450.00, 1, '10:30:00', '00:00:30');

-- --------------------------------------------------------

--
-- Table structure for table `utilizador`
--

CREATE TABLE `utilizador` (
  `EmailUtilizador` varchar(100) NOT NULL,
  `NomeUtilizador` varchar(200) NOT NULL,
  `TipoUtilizador` varchar(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `utilizador`
--

INSERT INTO `utilizador` (`EmailUtilizador`, `NomeUtilizador`, `TipoUtilizador`) VALUES
('aaa@aaa.com', 'Pedro', 'seg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `alerta`
--
ALTER TABLE `alerta`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `medicoessensores`
--
ALTER TABLE `medicoessensores`
  ADD PRIMARY KEY (`IDmedicao`);

--
-- Indexes for table `rondaextra`
--
ALTER TABLE `rondaextra`
  ADD PRIMARY KEY (`IDrondaExtra`),
  ADD KEY `EmaiUtilizador_fk` (`EmailUtilizador`);

--
-- Indexes for table `rondaplaneada`
--
ALTER TABLE `rondaplaneada`
  ADD PRIMARY KEY (`IDrondaPlaneada`),
  ADD KEY `EmaiUtilizador_fk2` (`EmailUtilizador`);

--
-- Indexes for table `sistema`
--
ALTER TABLE `sistema`
  ADD PRIMARY KEY (`LimiteTemperatura`);

--
-- Indexes for table `utilizador`
--
ALTER TABLE `utilizador`
  ADD PRIMARY KEY (`EmailUtilizador`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `alerta`
--
ALTER TABLE `alerta`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=89;

--
-- AUTO_INCREMENT for table `medicoessensores`
--
ALTER TABLE `medicoessensores`
  MODIFY `IDmedicao` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `rondaextra`
--
ALTER TABLE `rondaextra`
  MODIFY `IDrondaExtra` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `rondaplaneada`
--
ALTER TABLE `rondaplaneada`
  MODIFY `IDrondaPlaneada` int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `rondaextra`
--
ALTER TABLE `rondaextra`
  ADD CONSTRAINT `EmaiUtilizador_fk` FOREIGN KEY (`EmailUtilizador`) REFERENCES `utilizador` (`EmailUtilizador`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `rondaplaneada`
--
ALTER TABLE `rondaplaneada`
  ADD CONSTRAINT `EmaiUtilizador_fk2` FOREIGN KEY (`EmailUtilizador`) REFERENCES `utilizador` (`EmailUtilizador`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
