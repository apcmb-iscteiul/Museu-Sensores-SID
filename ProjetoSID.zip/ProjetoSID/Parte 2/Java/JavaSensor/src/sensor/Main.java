package sensor;

import sensor.CloudToMongo;

public class Main {

	public static void main(String[] args) {

		Frame b = new Frame();
		b.open();
		
		new CloudToMongo().connecCloud();
		new CloudToMongo().connectMongo();

		JavaMysql app = new JavaMysql(10, 2 , 10, 100);
		app.start();
	}
}
