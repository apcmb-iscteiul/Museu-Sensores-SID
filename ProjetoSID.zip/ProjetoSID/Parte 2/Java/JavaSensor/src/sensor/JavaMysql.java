package sensor;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collections;
import org.bson.Document;
import org.bson.conversions.Bson;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;
import static com.mongodb.client.model.Filters.*;

public class JavaMysql extends Thread {
	static Connection conn;
	static Statement s;
	static ResultSet rs;

	private int periodicidade = 10*1000;
	private double desvioTmpUtilizador;
	private double desvioHumUtilizador;
	private double desvioLuzUtilizador;

	private float medianaTmp = 0;
	private float medianaHum = 0;
	private float medianaLuz = 0;

	private float mediaTmp = 0;
	private float mediaHum = 0;
	private float mediaLuz = 0;

	private double desvioPadraoMediaTmp = 0;
	private double desvioPadraoMediaHum = 0;
	private double desvioPadraoMediaLuz = 0;

	private final String bdSql = "jdbc:mysql://localhost/museu_bymongo";
	private final String userSql = "root";
	private final String pwSql = "grupoPB";
	private final String driverSql = "com.mysql.cj.jdbc.Driver";

	private MongoClient mongoDB;
	private MongoDatabase db;
	private MongoCollection<Document> colecao;
	private final String mongoHost = "mongodb://localhost:27017,localhost:25017,localhost:23017/?replicaSet=replicademo&readPreference=primary&appname=MongoDB%20Compass%20Community&ssl=false";
	private final String mongoName = "museu";
	private final String mongoColecao = "medicoesTeste";

	private ArrayList<Medicao> listaMedicoes = new ArrayList<Medicao>();
	private ArrayList<Float> valoresMedianaAceitesTmp = new ArrayList<Float>();
	private ArrayList<Float> valoresMedianaAceitesHum = new ArrayList<Float>();
	private ArrayList<Float> valoresMedianaAceitesLuz = new ArrayList<Float>();

	public JavaMysql(int periodicidade, double desvioTmp, double desvioHum, double desvioLuz) {
		if(periodicidade > 10) {
			this.periodicidade = periodicidade * 1000;
		}
		this.desvioTmpUtilizador=desvioTmp;
		this.desvioHumUtilizador=desvioHum;
		this.desvioLuzUtilizador=desvioLuz;

		//Conecao ao mySql	
		try{ 	
			Class.forName(driverSql).newInstance();
			conn =  DriverManager.getConnection(bdSql+"?user="+userSql+"&password="+pwSql);
			System.out.println("Conectou SQL");
		}catch (Exception e){
			System.out.println("SQL n�o conectou");
		}

		try {
			//Conecao ao MongoDB
			mongoDB = new MongoClient(new MongoClientURI(mongoHost));
			db = mongoDB.getDatabase(mongoName);
			colecao = db.getCollection(mongoColecao);
			System.out.println("Conectou MongoDB");
		}catch (Exception e) {
			System.out.println("MongoDB n�o conectou");
		}
	}

	public void run() {

		while(true) {
			//Cria query para procurar no mongo por migrado 0
			Bson query2 = eq("migrado", "0");                    
			MongoCursor<Document> cursor2 = colecao.find(query2).iterator();

			try {
				//Le a colecao do mongo que tenha o campo migrado 0 e insere numa lista de medicoes
				while (cursor2.hasNext()) {
					Document obj = cursor2.next();
					listaMedicoes.add(new Medicao(obj.get("temperatura"), obj.get("humidade"),
							obj.get("luminosidade"), obj.get("movimento"), obj.get("data"), obj.get("hora"), 0, obj));

				}
				System.out.println("");
				System.out.println("Numero de Medicoes recebidas: " +listaMedicoes.size());
				System.out.println("");

				if (listaMedicoes.size() >= 3){                	
					MedianaComDesvioUtilizador();
					desvioPadraoDaMediaValoresAceites();
					verificaDesvioPadrao();                	               	
					insertSQL();         
					updateMongo();

					System.out.println("");
					System.out.println("---{MySql Updated}---");
					System.out.println("---{MongoDB Updated}---");
					System.out.println("");

					listaMedicoes.clear();
					valoresMedianaAceitesTmp.clear();
					valoresMedianaAceitesHum.clear();
					valoresMedianaAceitesLuz.clear();
				}

			} catch (SQLException e) {
				e.printStackTrace();
			}finally {
				cursor2.close();
			}
			try {
				Thread.sleep(periodicidade);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}


	private void desvioPadraoDaMediaValoresAceites() {
		System.out.println("");
		mediaTmp = media(valoresMedianaAceitesTmp);
		System.out.println("Media Tmp: "+mediaTmp);
		mediaHum = media(valoresMedianaAceitesHum);
		System.out.println("Media Hum: "+mediaHum);
		mediaLuz = media(valoresMedianaAceitesLuz);
		System.out.println("Media Luz: "+mediaLuz);
		System.out.println("");

		desvioPadraoMediaTmp = desvioPadraoMedia(mediaTmp, valoresMedianaAceitesTmp);
		System.out.println("DP Tmp: "+desvioPadraoMediaTmp);
		desvioPadraoMediaHum = desvioPadraoMedia(mediaHum, valoresMedianaAceitesHum);
		System.out.println("DP Hum: "+desvioPadraoMediaHum);
		desvioPadraoMediaLuz = desvioPadraoMedia(mediaLuz, valoresMedianaAceitesLuz);
		System.out.println("DP Luz: "+desvioPadraoMediaLuz);
		System.out.println("");
	}

	private void MedianaComDesvioUtilizador(){
		ArrayList<Float> temps = new ArrayList<Float>();
		ArrayList<Float> hums = new ArrayList<Float>();
		ArrayList<Float> cells = new ArrayList<Float>();

		//Adicionar valores a listas temporárias
		for (Medicao m : listaMedicoes) {
			temps.add(m.getTmpNum());
			hums.add(m.getHumNum());
			cells.add(m.getLuzNum());	
		}

		//Ordenar listas temporárias para cálculo
		Collections.sort(temps);
		Collections.sort(hums);
		Collections.sort(cells);

		//Calcular mediana das listas
		if (temps.size() % 2 == 0)
			medianaTmp = (temps.get((temps.size()/2)) + temps.get((temps.size()/2) + 1))/2;
		else
			medianaTmp = temps.get((temps.size() )/2);

		if (hums.size() % 2 == 0)
			medianaHum = (hums.get((hums.size()/2)) + hums.get((hums.size()/2) + 1))/2;
		else
			medianaHum = hums.get((hums.size() )/2);

		if (cells.size() % 2 == 0)
			medianaLuz = (cells.get((cells.size()/2)) + cells.get((cells.size()/2) + 1 ))/2;
		else
			medianaLuz = cells.get((cells.size() )/2);
		
		System.out.println("Mediana Temperatura: "+medianaTmp);
		System.out.println("Mediana Humidade: "+medianaHum);
		System.out.println("Mediana Luminosidade: "+medianaLuz);
		System.out.println("");
		
		//Inserir valores em listas respetivas se os mesmos não se desviarem mais que o permitido da mediana
		for (Medicao m: listaMedicoes) {
			float temp = m.getTmpNum();
			float hum = m.getHumNum();
			float cell = m.getLuzNum();
			
			//todos as medicoes aceites
			if ((temp >= medianaTmp - desvioTmpUtilizador && temp <= medianaTmp + desvioTmpUtilizador )
					&& (hum >= medianaHum - desvioHumUtilizador && hum <= medianaHum + desvioHumUtilizador)
					&& (cell >= medianaLuz - desvioLuzUtilizador && cell <= medianaLuz + desvioLuzUtilizador)) {
				m.setMigrado(111);
				valoresMedianaAceitesTmp.add(temp);
				valoresMedianaAceitesHum.add(hum);
				valoresMedianaAceitesLuz.add(cell);
				System.out.println("Mediana: Aceitei 111");
				//Mediana de Temperatura aceite com o desvio do Utilizador
			} else if ((temp >= medianaTmp - desvioTmpUtilizador && temp <= medianaTmp + desvioTmpUtilizador )
					&& (hum <= medianaHum - desvioHumUtilizador || hum >= medianaHum + desvioHumUtilizador)
					&& (cell <= medianaLuz - desvioLuzUtilizador || cell >= medianaLuz + desvioLuzUtilizador)) {
				m.setMigrado(100);
				valoresMedianaAceitesTmp.add(m.getTmpNum());
				System.out.println("Mediana: Aceitei 100");
				//Mediana de Humidade aceite com o desvio do Utilizador
			} else if ((temp <= medianaTmp - desvioTmpUtilizador || temp >= medianaTmp + desvioTmpUtilizador )
					&& (hum >= medianaHum - desvioHumUtilizador && hum <= medianaHum + desvioHumUtilizador)
					&& (cell <= medianaLuz - desvioLuzUtilizador || cell >= medianaLuz + desvioLuzUtilizador)) {
				m.setMigrado(010);
				valoresMedianaAceitesHum.add(m.getHumNum());
				System.out.println("Mediana: Aceitei 010");
				//Mediana de Luz aceite	com o desvio do Utilizador
			} else if ((temp <= medianaTmp - desvioTmpUtilizador || temp >= medianaTmp + desvioTmpUtilizador )
					&& (hum <= medianaHum - desvioHumUtilizador || hum >= medianaHum + desvioHumUtilizador)
					&& (cell >= medianaLuz - desvioLuzUtilizador && cell <= medianaLuz + desvioLuzUtilizador)) {
				m.setMigrado(001);
				valoresMedianaAceitesLuz.add(m.getLuzNum());
				System.out.println("Mediana: Aceitei 001");
				//Mediana de Temperatura e Humidade aceite com o desvio do utilizador	
			} else if ((temp >= medianaTmp - desvioTmpUtilizador && temp <= medianaTmp + desvioTmpUtilizador )
					&& (hum >= medianaHum - desvioHumUtilizador && hum <= medianaHum + desvioHumUtilizador)
					&& (cell <= medianaLuz - desvioLuzUtilizador || cell >= medianaLuz + desvioLuzUtilizador)) {
				m.setMigrado(110);
				valoresMedianaAceitesTmp.add(m.getTmpNum());
				valoresMedianaAceitesHum.add(m.getHumNum());
				System.out.println("Mediana: Aceitei 110");
				//Mediana de Temperatura e Luz aceite com o desvio do Utilizador
			} else if ((temp >= medianaTmp - desvioTmpUtilizador && temp <= medianaTmp + desvioTmpUtilizador )
					&& (hum <= medianaHum - desvioHumUtilizador || hum >= medianaHum + desvioHumUtilizador)
					&& (cell >= medianaLuz - desvioLuzUtilizador && cell <= medianaLuz + desvioLuzUtilizador)) {
				m.setMigrado(101);
				valoresMedianaAceitesTmp.add(m.getTmpNum());
				valoresMedianaAceitesLuz.add(m.getLuzNum());
				System.out.println("Mediana: Aceitei 101");
				//Mediana de Humidade e Luz aceite com o desvio do Utilizador
			} else if ((temp <= medianaTmp - desvioTmpUtilizador || temp >= medianaTmp + desvioTmpUtilizador )
					&& (hum >= medianaHum - desvioHumUtilizador && hum <= medianaHum + desvioHumUtilizador)
					&& (cell >= medianaLuz - desvioLuzUtilizador && cell <= medianaLuz + desvioLuzUtilizador)) {
				m.setMigrado(011);
				valoresMedianaAceitesHum.add(m.getHumNum());
				valoresMedianaAceitesLuz.add(m.getLuzNum());
				System.out.println("Mediana: Aceitei 011");
				//todas as medicoes rejeitadas	
			} else {
				m.setMigrado(000);				
				System.out.println("Mediana: Rejeitei 000");
			}
		}
	}

	private Float media (ArrayList<Float> list){
		float i = 0;
		for (Float f : list) {
			i += f.floatValue();
		}
		return i/list.size();
	}

	private Double desvioPadraoMedia(float media, ArrayList<Float> list){
		float variancia = 0;
		double desvio;
		for (Float f : list) {
			variancia += Math.pow(f - media, 2);
		}
		variancia = variancia/list.size();
		desvio = Math.sqrt(variancia);
		return desvio;
	}
	
	private void verificaDesvioPadrao() {

		for(Medicao m: listaMedicoes) {
			float tmp = m.getTmpNum();
			float hum = m.getHumNum();
			float cell = m.getLuzNum();

			//Se Temperatura aceite na mediana, verifica desvio padrao
			if(m.getMigrado().equals(100)){
				if(tmp >= mediaTmp - (desvioPadraoMediaTmp+desvioTmpUtilizador) && tmp <= mediaTmp + (desvioPadraoMediaTmp+desvioTmpUtilizador)) 
					m.setMigrado(100);    			   				
				else
					m.setMigrado(000);

				//Se Humidade aceite na mediana, verifica desvio padrao
			}else if(m.getMigrado().equals(010)) {
				if(hum >= mediaHum - (desvioPadraoMediaHum+desvioHumUtilizador) && hum <= mediaHum + (desvioPadraoMediaHum+desvioHumUtilizador)) 
					m.setMigrado(010);    			
				else
					m.setMigrado(000);

				//Se luz aceite na mediana, verifica desvio padrao
			}else if(m.getMigrado().equals(001)) {
				if(cell >= mediaLuz - (desvioPadraoMediaLuz+desvioLuzUtilizador) && cell <= mediaLuz + (desvioPadraoMediaLuz+desvioLuzUtilizador)) 
					m.setMigrado(001);
				else
					m.setMigrado(000);

				//Se Temperatura e Humidade aceites na mediana, verifica desvio padrao	
			}else if(m.getMigrado().equals(110)) {
				if((tmp >= mediaTmp - (desvioPadraoMediaTmp+desvioTmpUtilizador) && tmp <= mediaTmp + (desvioPadraoMediaTmp+desvioTmpUtilizador))
						&& (hum >= mediaHum - (desvioPadraoMediaHum+desvioHumUtilizador) && hum <= mediaHum + (desvioPadraoMediaHum+desvioHumUtilizador) ))
					m.setMigrado(110);
				else if((tmp >= mediaTmp - (desvioPadraoMediaTmp+desvioTmpUtilizador) && tmp <= mediaTmp + (desvioPadraoMediaTmp+desvioTmpUtilizador))
						&& (hum <= mediaHum - (desvioPadraoMediaHum+desvioHumUtilizador) || hum >= mediaHum + (desvioPadraoMediaHum+desvioHumUtilizador) )) 
					m.setMigrado(100);
				else if((tmp <= mediaTmp - (desvioPadraoMediaTmp+desvioTmpUtilizador) || tmp >= mediaTmp + (desvioPadraoMediaTmp+desvioTmpUtilizador))
						&& (hum >= mediaHum - (desvioPadraoMediaHum+desvioHumUtilizador) && hum <= mediaHum + (desvioPadraoMediaHum+desvioHumUtilizador) ))
					m.setMigrado(010);   			
				else
					m.setMigrado(000);

				//Se Temperatura e Luz s�o aceites na mediana, verifica desvio	
			}else if(m.getMigrado().equals(101)) {
				if((tmp >= mediaTmp - (desvioPadraoMediaTmp+desvioTmpUtilizador) && tmp <= mediaTmp + (desvioPadraoMediaTmp+desvioTmpUtilizador))
						&& (cell >= mediaLuz - (desvioPadraoMediaLuz+desvioLuzUtilizador) && cell <= mediaLuz + (desvioPadraoMediaLuz+desvioLuzUtilizador) ))
					m.setMigrado(101);
				else if((tmp >= mediaTmp - (desvioPadraoMediaTmp+desvioTmpUtilizador) && tmp <= mediaTmp + (desvioPadraoMediaTmp+desvioTmpUtilizador))
						&& (cell <= mediaLuz - (desvioPadraoMediaLuz+desvioLuzUtilizador) || cell >= mediaLuz + (desvioPadraoMediaLuz+desvioLuzUtilizador) )) 
					m.setMigrado(100);
				else if((tmp <= mediaTmp - (desvioPadraoMediaTmp+desvioTmpUtilizador) || tmp >= mediaTmp + (desvioPadraoMediaTmp+desvioTmpUtilizador))
						&& (cell >= mediaLuz - (desvioPadraoMediaLuz+desvioLuzUtilizador) && cell <= mediaLuz + (desvioPadraoMediaLuz+desvioLuzUtilizador) ))
					m.setMigrado(001);   			
				else
					m.setMigrado(000);
				//Se Humidade e Luz aceites na mediana, verifica desvio	
			}else if(m.getMigrado().equals(011)) {
				if((hum >= mediaHum - (desvioPadraoMediaHum+desvioHumUtilizador) && hum <= mediaHum + (desvioPadraoMediaHum+desvioHumUtilizador))
						&& (cell >= mediaLuz - (desvioPadraoMediaLuz+desvioLuzUtilizador) && cell <= mediaLuz + (desvioPadraoMediaLuz+desvioLuzUtilizador) ))
					m.setMigrado(011);
				else if((hum >= mediaHum - (desvioPadraoMediaHum+desvioHumUtilizador) && hum <= mediaHum + (desvioPadraoMediaHum+desvioHumUtilizador))
						&& (cell <= mediaLuz - (desvioPadraoMediaLuz+desvioLuzUtilizador) || cell >= mediaLuz + (desvioPadraoMediaLuz+desvioLuzUtilizador) )) 
					m.setMigrado(010);
				else if((hum <= mediaHum - (desvioPadraoMediaHum+desvioHumUtilizador) || hum >= mediaHum + (desvioPadraoMediaHum+desvioHumUtilizador))
						&& (cell >= mediaLuz - (desvioPadraoMediaLuz+desvioLuzUtilizador) && cell <= mediaLuz + (desvioPadraoMediaLuz+desvioLuzUtilizador) ))
					m.setMigrado(001);   			
				else
					m.setMigrado(000);

			}else if(m.getMigrado().equals(111)) {
				if((hum >= mediaHum - (desvioPadraoMediaHum+desvioHumUtilizador) && hum <= mediaHum + (desvioPadraoMediaHum+desvioHumUtilizador))
						&& (cell >= mediaLuz - (desvioPadraoMediaLuz+desvioLuzUtilizador) && cell <= mediaLuz + (desvioPadraoMediaLuz+desvioLuzUtilizador) )
						&& (tmp >= mediaTmp - (desvioPadraoMediaTmp+desvioTmpUtilizador) && tmp <= mediaTmp + (desvioPadraoMediaTmp+desvioTmpUtilizador)))
					m.setMigrado(111);
				else if((hum >= mediaHum - (desvioPadraoMediaHum+desvioHumUtilizador) && hum <= mediaHum + (desvioPadraoMediaHum+desvioHumUtilizador))
						&& (cell >= mediaLuz - (desvioPadraoMediaLuz+desvioLuzUtilizador) && cell <= mediaLuz + (desvioPadraoMediaLuz+desvioLuzUtilizador) )
						&& (tmp <= mediaTmp - (desvioPadraoMediaTmp+desvioTmpUtilizador) || tmp >= mediaTmp + (desvioPadraoMediaTmp+desvioTmpUtilizador)))
					m.setMigrado(011);
				else if((tmp >= mediaTmp - (desvioPadraoMediaTmp+desvioTmpUtilizador) && tmp <= mediaTmp + (desvioPadraoMediaTmp+desvioTmpUtilizador))
						&& (hum >= mediaHum - (desvioPadraoMediaHum+desvioHumUtilizador) && hum <= mediaHum + (desvioPadraoMediaHum+desvioHumUtilizador) )
						&& (cell <= mediaLuz - (desvioPadraoMediaLuz+desvioLuzUtilizador) || cell >= mediaLuz + (desvioPadraoMediaLuz+desvioLuzUtilizador) ))
					m.setMigrado(110);
				else if((tmp >= mediaTmp - (desvioPadraoMediaTmp+desvioTmpUtilizador) && tmp <= mediaTmp + (desvioPadraoMediaTmp+desvioTmpUtilizador))
						&& (cell >= mediaLuz - (desvioPadraoMediaLuz+desvioLuzUtilizador) && cell <= mediaLuz + (desvioPadraoMediaLuz+desvioLuzUtilizador) )
						&& (hum <= mediaHum - (desvioPadraoMediaHum+desvioHumUtilizador) || hum >= mediaHum + (desvioPadraoMediaHum+desvioHumUtilizador)))
					m.setMigrado(101);
				else if((tmp >= mediaTmp - (desvioPadraoMediaTmp+desvioTmpUtilizador) && tmp <= mediaTmp + (desvioPadraoMediaTmp+desvioTmpUtilizador))
						&& (hum <= mediaHum - (desvioPadraoMediaHum+desvioHumUtilizador) || hum >= mediaHum + (desvioPadraoMediaHum+desvioHumUtilizador) )
						&& (cell <= mediaLuz - (desvioPadraoMediaLuz+desvioLuzUtilizador) || cell >= mediaLuz + (desvioPadraoMediaLuz+desvioLuzUtilizador) )) 
					m.setMigrado(100);
				else if((tmp >= mediaTmp - (desvioPadraoMediaTmp+desvioTmpUtilizador) || tmp >= mediaTmp + (desvioPadraoMediaTmp+desvioTmpUtilizador))
						&& (hum >= mediaHum - (desvioPadraoMediaHum+desvioHumUtilizador) && hum <= mediaHum + (desvioPadraoMediaHum+desvioHumUtilizador) )
						&& (cell <= mediaLuz - (desvioPadraoMediaLuz+desvioLuzUtilizador) || cell >= mediaLuz + (desvioPadraoMediaLuz+desvioLuzUtilizador) ))
					m.setMigrado(010);
				else if((tmp <= mediaTmp - (desvioPadraoMediaTmp+desvioTmpUtilizador) || tmp >= mediaTmp + (desvioPadraoMediaTmp+desvioTmpUtilizador))
						&& (hum <= mediaHum - (desvioPadraoMediaHum+desvioHumUtilizador) || hum >= mediaHum + (desvioPadraoMediaHum+desvioHumUtilizador))
						&& (cell >= mediaLuz - (desvioPadraoMediaLuz+desvioLuzUtilizador) && cell <= mediaLuz + (desvioPadraoMediaLuz+desvioLuzUtilizador) ))
					m.setMigrado(001);								 			
				else
					m.setMigrado(000);
			}
		}
	}

	private void insertSQL() throws SQLException {

		Statement insert = conn.createStatement();

		for (Medicao m : listaMedicoes) {
			
			if(m.getMigrado().equals(100))	{    			
				insert.addBatch(m.callSpTmp());
				System.out.println("MySql: 100"); 
			}

			else if(m.getMigrado().equals(010))	{
				insert.addBatch(m.callSpHum());
				System.out.println("MySql: 010");     			
			}

			else if(m.getMigrado().equals(001))	{		
				insert.addBatch(m.callSpLuz());
				System.out.println("MySql: 001"); 
			}

			else if(m.getMigrado().equals(110))	{				
				insert.addBatch(m.callSpTmp());
				insert.addBatch(m.callSpHum());
				System.out.println("MySql: 110"); 
			}

			else if(m.getMigrado().equals(101))	{
				insert.addBatch(m.callSpTmp());
				insert.addBatch(m.callSpLuz());
				System.out.println("MySql: 101"); 
			}

			else if(m.getMigrado().equals(011))	{
				insert.addBatch(m.callSpHum());
				insert.addBatch(m.callSpLuz());
				System.out.println("MySql: 011"); 
			}

			else if(m.getMigrado().equals(111))	{
				insert.addBatch(m.callSpTmp());
				insert.addBatch(m.callSpHum());
				insert.addBatch(m.callSpLuz());
				System.out.println("MySql: 111"); 
			}
			
			if(m.getMov() == 0 || m.getMov() == 1) 
				insert.addBatch(m.callSpMov());
		}
		insert.executeBatch();
		insert.close();
	}   	

	//faz o update do campo migrao da colecao mongo, conforme a aceita��o dos valores que foram inseridos no MySql
	private void updateMongo () {
		for (Medicao m : listaMedicoes){
			if (m.getMigrado()== 000){
				Bson newValue = new Document("migrado", "000");
				Bson updateOperationDocument = new Document("$set", newValue);
				colecao.updateOne(m.getDocumento(), updateOperationDocument);
			}
			else if (m.getMigrado()== 100 ){
				Bson newValue = new Document("migrado", "100");
				Bson updateOperationDocument =  new Document("$set", newValue);
				colecao.updateOne(m.getDocumento(), updateOperationDocument);         
			}
			else if (m.getMigrado()== 010){
				Bson newValue = new Document("migrado", "010");
				Bson updateOperationDocument = new Document("$set", newValue);
				colecao.updateOne(m.getDocumento(),updateOperationDocument);
			}
			else if (m.getMigrado()==001 ){
				Bson newValue = new Document("migrado", "001");
				Bson updateOperationDocument = new Document("$set", newValue);
				colecao.updateOne(m.getDocumento(), updateOperationDocument);
			}
			else if (m.getMigrado()==110 ){
				Bson newValue = new Document("migrado", "110");
				Bson updateOperationDocument = new Document("$set", newValue);
				colecao.updateOne(m.getDocumento(), updateOperationDocument);
			}
			else if (m.getMigrado()==101){
				Bson newValue = new Document("migrado", "101");
				Bson updateOperationDocument =new Document("$set", newValue);
				colecao.updateOne(m.getDocumento(), updateOperationDocument);
			}
			else if (m.getMigrado()==011 ){
				Bson newValue = new Document("migrado", "011");
				Bson updateOperationDocument = new Document("$set", newValue);
				colecao.updateOne(m.getDocumento(), updateOperationDocument);
			}
			else if (m.getMigrado()==111 ){
				Bson newValue = new Document("migrado", "111");
				Bson updateOperationDocument = new Document("$set", newValue);
				colecao.updateOne(m.getDocumento(), updateOperationDocument);
			}
		}
	}
}