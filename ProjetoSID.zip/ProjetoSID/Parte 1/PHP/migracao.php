<?php

$user = 'root';
$pass = 'grupo31';
$db = 'museumainbd';
$db2 = 'migracaologsphp';

$conn = new mysqli('localhost', $user , $pass , $db ) or die ("Conexão Falhada");
$conn2 = new mysqli('localhost', $user , $pass , $db2 ) or die ("Conexão Falhada");


//LOG-ALERTAS
$sql = "Select * from alertaslog";
$result = mysqli_query($conn, $sql);

$sqlTruncate = "TRUNCATE alertaslog";
mysqli_query($conn2, $sqlTruncate);     

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        $sql2 = "INSERT INTO `alertaslog` (`IDlog`, `IDalerta`, `IDmedicao`, `EstadoAlerta`, `Descricao`, `Operacao`, `dataOperacao`, `userOperacao`, `Export`) VALUES (" . $row["IDlog"] . "," . $row["IDalerta"] . "," . $row["IDmedicao"] . "," . $row["EstadoAlerta"] . ",'" . $row["Descricao"] . "','" . $row["Operacao"] . "', '" . $row["dataOperacao"] . "', '" . $row["userOperacao"] . "',0);"; 
       	$result2 = mysqli_query($conn2, $sql2); 		
    }
} else {
	echo "0 results";
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//LOG-MEDICOES
$sql = "Select * from medicoeslog";
$result = mysqli_query($conn, $sql);

$sqlTruncate = "TRUNCATE medicoeslog";
mysqli_query($conn2, $sqlTruncate);   

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        $sql2 = "INSERT INTO `medicoeslog` (`IDlog`, `IDmedicao`, `ValorMedicaoOld`,`ValorMedicaoNew`, `TipoSensor`, `DataHoraMedicao`, `Operacao`, `DataOperacao`, `UserOperacao`, `Export`) VALUES (" . $row["IDlog"] . "," . $row["IDmedicao"] . "," . $row["ValorMedicaoOld"] . "," . $row["ValorMedicaoNew"] . ",'" . $row["TipoSensor"] . "','" . $row["DataHoraMedicao"] . "','" . $row["Operacao"] . "', '" . $row["DataOperacao"] . "', '" . $row["UserOperacao"] . "',0)"; 
       	$result2 = mysqli_query($conn2, $sql2);
    }
} else {
	echo "0 results";
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//LOG-RONDA EXTRA
$sql = "Select * from rondaextralog";
$result = mysqli_query($conn, $sql);

$sqlTruncate = "TRUNCATE rondaextralog";
mysqli_query($conn2, $sqlTruncate);  

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        $sql2 = "INSERT INTO `rondaextralog` (`IDlog`, `EmailUtilizador`, `dataHora`, `Operacao`, `dataOperacao`, `UserOperacao`, `Export`) VALUES (" . $row["IDlog"] . ", '" . $row["EmailUtilizador"] . "', '" . $row["dataHora"] . "', '" . $row["Operacao"] . "', '" . $row["dataOperacao"] . "', '" . $row["UserOperacao"] . "',1)";
       	$result2 = mysqli_query($conn2, $sql2);
    }
} else {
	echo "0 results";
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//LOG-RONDA PLANEADA
$sql = "Select * from rondaplaneadalog";
$result = mysqli_query($conn, $sql);

$sqlTruncate = "TRUNCATE rondaplaneadalog";
mysqli_query($conn2, $sqlTruncate);     

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        $sql2 = "INSERT INTO `rondaplaneadalog` (`IDlog`, `DiaSemana`, `EmailUtilizador`, `Operacao`, `dataOperacao`, `UserOperacao`, `Export`) VALUES (" . $row["IDlog"] . ", '" . $row["DiaSemana"] . "', '" . $row["EmailUtilizador"] . "', '" . $row["Operacao"] . "', '" . $row["dataOperacao"] . "', '" . $row["UserOperacao"] . "',0)"; 
       	$result2 = mysqli_query($conn2, $sql2);	
    }
} else {
	echo "0 results";
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

//LOG-SISTEMA
$sql = "Select * from sistemalog";
$result = mysqli_query($conn, $sql);

$sqlTruncate = "TRUNCATE sistemalog";
mysqli_query($conn2, $sqlTruncate);     

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        $sql2 = "INSERT INTO sistemalog (IDlog,LimiteTemperatura,LimiteHumidade,LimiteLuminosidade,movimento,Operacao,dataOperacao,UserOperacao,Export) VALUES (" . $row["IDlog"] . "," . $row["LimiteTemperatura"] . "," . $row["LimiteHumidade"] . "," . $row["LimiteLuminosidade"] . "," . $row["movimento"] . ", '" . $row["Operacao"] . "', '" . $row["dataOperacao"] . "', '" . $row["UserOperacao"] . "',0)"; 
       	$result2 = mysqli_query($conn2, $sql2);
    }
} else {
	echo "0 results";
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

//LOG-UTILIZADOR
$sql = "Select * from utilizadorlog";
$result = mysqli_query($conn, $sql);

$sqlTruncate = "TRUNCATE utilizadorlog";
mysqli_query($conn2, $sqlTruncate);     

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        $sql2 = "INSERT INTO utilizadorlog (IDlog, EmailUtilizador, NomeUtilizador, Passwordd ,Morada,TipoUtilizador,Operacao,DataOperacao,UserOperacao,Export) VALUES (" . $row["IDlog"] . ", '" . $row["EmailUtilizador"] . "', '" . $row["NomeUtilizador"] . "','" . $row["Passwordd"] . "','" . $row["Morada"] . "', '" . $row["TipoUtilizador"] . "', '" . $row["Operacao"] . "', '" . $row["DataOperacao"] . "', '" . $row["UserOperacao"] . "',0)"; 
       	$result2 = mysqli_query($conn2, $sql2);
    }
} else {
	echo "0 results";
}
$conn->close();
?>

